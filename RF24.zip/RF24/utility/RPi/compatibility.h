#ifndef RF24_UTILITY_RPI_COMPATIBLITY_H_
#define RF24_UTILITY_RPI_COMPATIBLITY_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

uint32_t millis(void);

#ifdef __cplusplus
}
#endif

#endif // RF24_UTILITY_RPI_COMPATIBLITY_H_
